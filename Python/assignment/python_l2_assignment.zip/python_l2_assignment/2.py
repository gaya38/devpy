email="From abc.xyz@pqr.com Mon Dec 29 01:12:15 2016"
print 'email id:',email[5:20]
print 'domain name:',email[13:20]
print 'time:',email[32:40]
